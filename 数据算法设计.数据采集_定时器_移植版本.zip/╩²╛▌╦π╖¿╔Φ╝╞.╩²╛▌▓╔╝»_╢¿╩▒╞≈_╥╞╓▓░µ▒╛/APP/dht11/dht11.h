#ifndef _dht11_H
#define _dht11_H

#include "system.h"
#include "SysTick.h"


#define DHT11 (GPIO_Pin_0) //PA0
#define GPIO_DHT11 GPIOA

#define DHT11_DQ_IN PAin(0)	  //����
#define DHT11_DQ_OUT PAout(0)  //���

void DHT11_IO_OUT(void);
void DHT11_IO_IN(void);
u8 DHT11_Init(void);
void DHT11_Rst(void);
u8 DHT11_Check(void);
u8 DHT11_Read_Bit(void);
u8 DHT11_Read_Byte(void);
u8 DHT11_Read_Data(u8 *temp,u8 *humi);


#endif
