#include "rasp.h"
#include "input.h"
#include "usart.h"
#include "dht11.h"
#include "ds18b20.h"
#include "SysTick.h"
#include "time.h"
#include "usart2.h"

u32 indata=0;  //֮ǰ���벶���õĺ�������
// �������õ�һϵ�б���
u8 temp = 0;
u8 humi = 0;
float ds18b20 = 0;
int ds18b20_d = 0;

unsigned char ASC_trans(int x)  //����һ��ʮ����תASCII��ĺ���
{
	switch(x)
		{
			case 1 : return 0x31;
			case 2 : return 0x32;
			case 3 : return 0x33;
			case 4 : return 0x34;
			case 5 : return 0x35;
			case 6 : return 0x36;
			case 7 : return 0x37;
			case 8 : return 0x38;
			case 9 : return 0x39;
			case 0 : return 0x30;
    }
}


 //����ݮ��/���ԵĴ���ĺ�������ҪTIM2��ʱ����period����ʱʱ�䣨�����㣩
void data_send_raspberry(int period)
{

	extern u16 i;
	extern u8 temp ;
	extern u8 humi ;
	u8 j = 0;
	u16 k = 0;
	extern float ds18b20 ;
	extern int ds18b20_d ;
	extern u8 pre_data[];
	DHT11_Init();
	DS18B20_Init();
	TIM2_Init(5000,7200-1);  //TIM2 ��ʱ�������ڶ�ʱ500ms
	while(DHT11_Check())  //��⴫����
		{
			USART_SendByte(USART1 , 0x45);
			USART_SendByte(USART1 , 0x52);
			USART_SendByte(USART1 , 0x52);
			USART_SendByte(USART1 , 0x4f);
			USART_SendByte(USART1 , 0x52);
			USART_SendByte(USART1 , 0x31);
			USART_SendByte(USART1 , 0x0a);
			///print "ERROR1\n"
			USART_SendByte(USART2 , 0x45);
			USART_SendByte(USART2 , 0x52);
			USART_SendByte(USART2 , 0x52);
			USART_SendByte(USART2 , 0x4f);
			USART_SendByte(USART2 , 0x52);
			USART_SendByte(USART2 , 0x31);
			USART_SendByte(USART2 , 0x0a);
			delay_ms(500);
		}
	while(DS18B20_Init()) //��⴫����
		{
			USART_SendByte(USART1 , 0x45);
			USART_SendByte(USART1 , 0x52);
			USART_SendByte(USART1 , 0x52);
			USART_SendByte(USART1 , 0x4f);
			USART_SendByte(USART1 , 0x52);
			USART_SendByte(USART1 , 0x32);
			USART_SendByte(USART1 , 0x0a);
			///print "ERROR2\n"
			USART_SendByte(USART2 , 0x45);
			USART_SendByte(USART2 , 0x52);
			USART_SendByte(USART2 , 0x52);
			USART_SendByte(USART2 , 0x4f);
			USART_SendByte(USART2 , 0x52);
			USART_SendByte(USART2 , 0x31);
			USART_SendByte(USART2 , 0x0a);
			delay_ms(500);
		}
	
	while(i)
	{
		if(i%(2*period + 1) == 0)  //����ѭ��ʱ����
		{	k++;
			for(j=0 ; j<1 ; j++)
				{
					DHT11_Read_Data(&temp,&humi);		//dht11��ȡ��ʪ��ֵ
					ds18b20 = DS18B20_GetTemperture();  //ds18b20��ȡ�¶�ֵ
					USART_SendByte(USART2 , ASC_trans(temp/100));
					USART_SendByte(USART2 , ASC_trans(temp%100/10));
					USART_SendByte(USART2 , ASC_trans(temp%10));
					USART_SendByte(USART2 , 0x20);
					//USART_SendByte(USART1 , 0x0a);
					//print "temp,"
					USART_SendByte(USART2 , ASC_trans(humi/100));
					USART_SendByte(USART2 , ASC_trans(humi%100/10));
					USART_SendByte(USART2 , ASC_trans(humi%10));
					USART_SendByte(USART2 , 0x20);
					//USART_SendByte(USART1 , 0x0a);
					//print "humi,"
					ds18b20_d = (int)(ds18b20*100);
					USART_SendByte(USART2 , ASC_trans(ds18b20_d/1000));
					USART_SendByte(USART2 , ASC_trans(ds18b20_d%1000/100));
					USART_SendByte(USART2 , 0x2e);// "."
					USART_SendByte(USART2 , ASC_trans(ds18b20_d%100/10));
					USART_SendByte(USART2 , ASC_trans(ds18b20_d%10));
					//USART_SendByte(USART2 , 0x2c);
					//USART_SendByte(USART1 , 0x0a);
					//print "ds18b20,"
					USART_SendByte(USART1 , pre_data[0]); //ͨ��USART1���ڷ���Ԥ��ʱ������
					USART_SendByte(USART1 , pre_data[1]);
					USART_SendByte(USART1 , pre_data[2]);
					USART_SendByte(USART2 , 0x0a);
					USART_SendByte(USART1 , pre_data[3]);
					USART_SendByte(USART1 , 0x0a);
					
				}
			i = 1;  //��ʱi�ָ���ֵ
		}
		
	}

}

