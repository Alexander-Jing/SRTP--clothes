#ifndef _rasp_H
#define _rasp_H

#include "system.h"

extern unsigned char ASC_trans(int x);
void data_get_for_raspberry(int period);

#endif
