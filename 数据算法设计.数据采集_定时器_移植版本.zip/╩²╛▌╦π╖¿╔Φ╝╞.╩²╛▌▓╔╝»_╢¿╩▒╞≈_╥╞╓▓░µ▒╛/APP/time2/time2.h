#ifndef _time2_H
#define _time2_H

#include "system.h"

void TIM2_Init(u16 per,u16 psc);

#endif
