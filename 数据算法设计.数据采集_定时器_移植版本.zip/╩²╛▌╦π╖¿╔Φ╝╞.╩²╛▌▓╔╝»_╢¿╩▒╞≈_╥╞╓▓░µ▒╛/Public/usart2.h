#ifndef __usart2_H
#define __usart2_H

#include "system.h" 
#include "stdio.h" 


void USART2_Init(u32 bound);

#endif
