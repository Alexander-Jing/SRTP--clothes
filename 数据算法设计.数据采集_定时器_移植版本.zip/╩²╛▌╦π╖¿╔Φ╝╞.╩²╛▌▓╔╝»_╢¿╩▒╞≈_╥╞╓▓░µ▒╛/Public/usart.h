#ifndef __usart_H
#define __usart_H

#include "system.h" 
#include "stdio.h" 

void USART1_Init(u32 bound);
void USART_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
u16 USART_ReceiveByte( USART_TypeDef * pUSARTx );
#endif


