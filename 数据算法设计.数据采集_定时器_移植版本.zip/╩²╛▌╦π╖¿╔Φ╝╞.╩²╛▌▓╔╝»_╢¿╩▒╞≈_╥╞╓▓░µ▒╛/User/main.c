

#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "input.h"
#include "pwm.h"
#include "rasp.h"
#include "time2.h"
#include "usart2.h"


/*******************************************************************************
* 函 数 名         : main
* 函数功能		   : 主函数
* 输    入         : 无
* 输    出         : 无
*******************************************************************************/
int main()
{
	
	SysTick_Init(72);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //中断优先级分组 分2组
	USART1_Init(115200);
	USART2_Init(115200);
	data_send_raspberry(3);
	
}
